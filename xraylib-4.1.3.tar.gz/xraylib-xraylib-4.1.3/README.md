xraylib: a library for interactions of X-rays with matter 
=========================================================

Welcome to the __xraylib__ Github project page!

For all information, consult the **[official documentation](http://github.com/tschoonj/xraylib/wiki)**

![CI](https://github.com/tschoonj/xraylib/workflows/CI/badge.svg?branch=master&event=push) [![Maven Central](https://img.shields.io/maven-central/v/com.github.tschoonj/xraylib.svg?label=Maven%20Central)](https://search.maven.org/search?q=g:%22com.github.tschoonj%22%20AND%20a:%22xraylib%22) [![Total alerts](https://img.shields.io/lgtm/alerts/g/tschoonj/xraylib.svg?logo=lgtm&logoWidth=18)](https://lgtm.com/projects/g/tschoonj/xraylib/alerts/) [![Language grade: Python](https://img.shields.io/lgtm/grade/python/g/tschoonj/xraylib.svg?logo=lgtm&logoWidth=18)](https://lgtm.com/projects/g/tschoonj/xraylib/context:python) [![Language grade: C/C++](https://img.shields.io/lgtm/grade/cpp/g/tschoonj/xraylib.svg?logo=lgtm&logoWidth=18)](https://lgtm.com/projects/g/tschoonj/xraylib/context:cpp) [![Language grade: Java](https://img.shields.io/lgtm/grade/java/g/tschoonj/xraylib.svg?logo=lgtm&logoWidth=18)](https://lgtm.com/projects/g/tschoonj/xraylib/context:java)

Get in touch using Gitter [![Gitter](https://badges.gitter.im/xraylib/community.svg)](https://gitter.im/xraylib/community?utm_source=badge&utm_medium=badge&utm_campaign=pr-badge)
