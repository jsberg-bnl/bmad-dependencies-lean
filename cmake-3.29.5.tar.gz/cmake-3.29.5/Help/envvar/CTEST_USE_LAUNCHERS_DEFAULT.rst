CTEST_USE_LAUNCHERS_DEFAULT
---------------------------

.. include:: ENV_VAR.txt

Initializes the :variable:`CTEST_USE_LAUNCHERS` variable if not already defined.
