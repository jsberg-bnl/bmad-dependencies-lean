var searchData=
[
  ['gsl_5fcomplex',['gsl_complex',['../structfgsl_1_1gsl__complex.html',1,'fgsl']]],
  ['gsl_5fsf_5fresult',['gsl_sf_result',['../structfgsl_1_1gsl__sf__result.html',1,'fgsl']]],
  ['gsl_5fsf_5fresult_5fe10',['gsl_sf_result_e10',['../structfgsl_1_1gsl__sf__result__e10.html',1,'fgsl']]]
];
