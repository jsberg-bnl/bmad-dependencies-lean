var searchData=
[
  ['numit',['numit',['../structfgsl_1_1fgsl__multifit__robust__stats.html#a9dcebe91b1e3a34ccb49129f10c861bc',1,'fgsl::fgsl_multifit_robust_stats']]]
];
