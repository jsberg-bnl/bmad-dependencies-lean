var searchData=
[
  ['dat',['dat',['../structfgsl_1_1gsl__complex.html#a50388c80381b51ae88a07ed9726edf27',1,'fgsl::gsl_complex']]],
  ['dof',['dof',['../structfgsl_1_1fgsl__multifit__robust__stats.html#a4490c5d81e7802e064b1ad9910b42b3b',1,'fgsl::fgsl_multifit_robust_stats']]]
];
