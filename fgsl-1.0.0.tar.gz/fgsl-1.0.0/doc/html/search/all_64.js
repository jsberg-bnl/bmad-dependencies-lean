var searchData=
[
  ['dat',['dat',['../structfgsl_1_1gsl__complex.html#a50388c80381b51ae88a07ed9726edf27',1,'fgsl::gsl_complex']]],
  ['deriv_2efinc',['deriv.finc',['../deriv_8finc.html',1,'']]],
  ['dht_2efinc',['dht.finc',['../dht_8finc.html',1,'']]]
];
