var searchData=
[
  ['sigma',['sigma',['../structfgsl_1_1fgsl__multifit__robust__stats.html#a5da53015a9d12f1c5efca715e3db852b',1,'fgsl::fgsl_multifit_robust_stats']]],
  ['sigma_5fmad',['sigma_mad',['../structfgsl_1_1fgsl__multifit__robust__stats.html#aa9d516d07e5792e733b0074d4b402999',1,'fgsl::fgsl_multifit_robust_stats']]],
  ['sigma_5fols',['sigma_ols',['../structfgsl_1_1fgsl__multifit__robust__stats.html#adf176fab65c7036d151f74de617d219a',1,'fgsl::fgsl_multifit_robust_stats']]],
  ['sigma_5frob',['sigma_rob',['../structfgsl_1_1fgsl__multifit__robust__stats.html#a5584eeb03f4001749227079089275075',1,'fgsl::fgsl_multifit_robust_stats']]],
  ['sse',['sse',['../structfgsl_1_1fgsl__multifit__robust__stats.html#a137f634721561413a40c1269d954a504',1,'fgsl::fgsl_multifit_robust_stats']]]
];
