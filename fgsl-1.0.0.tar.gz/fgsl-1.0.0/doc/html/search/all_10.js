var searchData=
[
  ['type',['type',['../structfgsl_1_1fgsl__rng__type.html#a124544a893fbccaf500ab420de1dfa6b',1,'fgsl::fgsl_rng_type::type()'],['../structfgsl_1_1fgsl__qrng__type.html#a3e0ae09be0c95e66fe6bef740c4d2688',1,'fgsl::fgsl_qrng_type::type()']]]
];
