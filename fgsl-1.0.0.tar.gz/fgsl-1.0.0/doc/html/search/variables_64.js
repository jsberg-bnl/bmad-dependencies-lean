var searchData=
[
  ['dat',['dat',['../structfgsl_1_1gsl__complex.html#a50388c80381b51ae88a07ed9726edf27',1,'fgsl::gsl_complex']]]
];
