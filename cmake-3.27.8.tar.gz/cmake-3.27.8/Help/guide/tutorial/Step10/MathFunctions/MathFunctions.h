namespace mathfunctions {
double sqrt(double x);
}
